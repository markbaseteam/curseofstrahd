### Abraham Van Helsing

North Sarcophagus. The vestige within this sarcophagus offers the dark gift of Yrrga, the Eye of Shadows. Yrrga’s gift is the power of true seeing. This dark gift grants its beneficiary the benefits of [truesight](https://www.dndbeyond.com/compendium/rules/basic-rules/monsters#Truesight) out to a range of 60 feet. These benefits last for 30 days, after which the dark gift vanishes.

The eyes of the beneficiary become starry voids until the dark gift vanishes. The beneficiary of this dark gift also gains the following flaw: “I believe that all life is pointless and look forward to death when it finally comes.”

---

### Prime Storm

West Sarcophagus. The vestige within this sarcophagus offers the dark gift of Great Taar Haak, the Five-Headed Destroyer. Taar Haak’s gift is great strength. This dark gift grants its beneficiary the benefit of a [belt of fire giant strength](https://www.dndbeyond.com/magic-items/4828-belt-of-fire-giant-strength). This benefit lasts for 10 days, after which the dark giftvanishes.

The beneficiary of this dark gift the following flaw: “I like to bully others and make them feel weak and inferior.”

---

### Nikoli of the North

South Sarcophagus. The vestige within this sarcophagus offers the dark gift of Yog the Invincible. Yog’s gift is one of physical resilience. This dark gift increases the beneficiary’s hit point maximum by 30. This benefit lasts for 10 days, after which the dark gift vanishes.

Oily black fur covers the beneficiary’s face and body.